#include <avr/io.h>

#include "avr_lib.h"
#include <util/delay.h>
#include <avr/pgmspace.h>
#include "font.h"
#include "oled.h"

extern const char FONT5X7[][5];
extern const char FONT8X15[][8][2];

const unsigned char gamma[] = {
	0x01,0x04,0x07,0x09,
	0x0B,0x0C,0x0D,0x0E,
	0x0F,0x10,0x11,0x12,
	0x13,0x16,0x1d,0x21,
	0x23,0x24,0x2E,0x31,
	0x32,0x37,0x41,0x43,
	0x4c,0x51,0x54,0x61,
	0x68,0x6f,0x75,0x7f,//
	
	0x01,0x08,0x0E,0x13,
	0x17,0x1a,0x1c,0x1e,
	0x1f,0x20,0x21,0x22,
	0x23,0x25,0x2b,0x30,
	0x31,0x33,0x37,0x39,
	0x41,0x43,0x47,0x50,
	0x52,0x55,0x61,0x63,
	0x64,0x70,0x74,0x7f,//

	0x01,0x04,0x07,0x09,
	0x0B,0x0C,0x0D,0x0E,
	0x0F,0x10,0x11,0x12,
	0x13,0x16,0x1E,0x21,
	0x22,0x25,0x2d,0x30,
	0x32,0x37,0x41,0x43,
	0x4c,0x51,0x56,0x62,
	0x69,0x70,0x77,0x7f
};

//==================================================
// Delay us
//==================================================

void delay_1us(unsigned char u)
{
	_delay_us(u);						
}

//==================================================
// Delay ms
//==================================================
void DelayMs(unsigned int delay)
{
	while(delay--)
		_delay_ms(1);
}

//==================================================
//==================================================
void SetAddr(unsigned char x, unsigned char y)
{
  
	write_cmd(SET_COLUMN_ADDRESS); //colum �ּ� 
	write_data(x); 
	write_data(0x7f);
	
	
	write_cmd(SET_ROW_ADDRESS);
	write_data(y);
	write_data(0x7f);
	
	write_cmd(WRITE_GRAM);
}


//==================================================
// Plot one point
// at x,y with pixel color
//==================================================
void PutPixel(unsigned char x, unsigned char y, unsigned int color)
{
	SetAddr(x,y);
	write_data(color >> 8);
	write_data(color);
}

//======================================================================//
void initOLED(void)
{		
	
	OLED_CTRL_DDR	=	0xFF;
	OLED_DATA_DDR	=	0xFF;

	OLED_CTRL_PORT	=	0xFF;
	OLED_DATABUS = 0;
	
	Reset_SSD1355();
	
	write_cmd(SOFT_RESET); 
	
	write_cmd(COMMAD_LOCK); 
	write_data(0x12); 

	write_cmd(COMMAD_LOCK); 
	write_data(0xB3); 
	
	write_cmd(SLEEP_MODE_ON);

	write_cmd(CLOCK_FREQUENCY); 
	write_data(0x10);
	
	write_cmd(SET_MUX_RATIO); 
	write_data(0x7f);  //127

	write_cmd(SET_DISPLAY_OFFSET); 
	write_data(0x00); 

	write_cmd(MEMORY_ACCSEE_CNTL); 
	write_data(0x88); 
	write_data(0x01); 

	write_cmd(INTERFACE_PIXEL_FORMAT); 
	write_data(_65K_COLOURS); 
	
	write_cmd(EN_T_EFFECT); 
	write_data(0x00); 

	write_cmd(FUNC_SEL); 
	write_data(0x03); 

	write_cmd(CONTRAST_RGB); 
	write_data(0xc3); 
	write_data(0x55); 
	write_data(0x87); 
	
	write_cmd(WRITE_LUMINANCE); 
	write_data(0xF0); 
	
	write_cmd(GAMMA_LUT); 		
	
	u08 j;
	for(j=0;j<96;j++)
		write_data(gamma[j]);		
	
	write_cmd(SET_PHASE_LENGTH); 
	write_data(0x32); 

	write_cmd(FIRST_PRECHARGE); 
	write_data(0x09); 

	write_cmd(SECOND_PRECHARGE_PERIOD); 
	write_data(0x0b); 

	write_cmd(SET_2TH_PRECHARGE_SPEED); 
	write_data(0x03); 

	write_cmd(SET_VCOMH); 
	write_data(0x04); 

	write_cmd(DISPLAY_ALL_ONOFF); 

	write_cmd(DISPLAY_INVERSE_OFF); 
	
	write_cmd(DISPLAY_NORMAL); 

	write_cmd(SLEEP_MODE_OFF); 
	

}

//======================================================================//
//======================================================================//
void Reset_SSD1355(void)
{
	DelayMs(1);
	cbi(OLED_CTRL_PORT,RESETPIN_OLED);		// IOCLR=bRES;
	delay_1us(2);
	sbi(OLED_CTRL_PORT,RESETPIN_OLED);		// IOSET=bRES;
	DelayMs(1);
}


void write_cmd(unsigned char cmd)
{
	cbi(OLED_CTRL_PORT,D_C);				// IOCLR=bD_C;	
	cbi(OLED_CTRL_PORT,WN_OLED);			// IOCLR=bR_W;
	cbi(OLED_CTRL_PORT,CS_OLED);			// IOCLR=bCS;

	OLED_DATABUS = cmd;		// IOSET=cmd;
	asm("nop");

	sbi(OLED_CTRL_PORT,WN_OLED);			// IOSET=bR_W;
	sbi(OLED_CTRL_PORT,CS_OLED);			// IOSET=bCS;
}

//======================================================================//
//======================================================================//
void write_data(unsigned char data)
{
	sbi(OLED_CTRL_PORT,D_C);				// IOSET=bD_C;
	cbi(OLED_CTRL_PORT,CS_OLED);			// IOCLR=bCS;
	cbi(OLED_CTRL_PORT,WN_OLED);			// IOCLR=bR_W;

	OLED_DATABUS = data;	// IOSET=data;
	asm("nop");

	sbi(OLED_CTRL_PORT,CS_OLED);			// IOSET=bCS;
	sbi(OLED_CTRL_PORT,WN_OLED);			// IOSET=bR_W;

}


//-----------------------------------------------------------------------------
// Function:    OLED_DrawImage
// Parameters:  left/top are the x/y coordinates of the top/left corner 
//              (for 4bpp x has to be an even number)
//              width/height of image (has to match image properties)
//              (for 4bpp width has to be an even number)
//              mask allows to shift the gray scale levels (e.g. to darken a picture)
// Returns:     nothing
// Description: sets a canvas the size of width/heigth and fills it with the
//              data of the image 
//-----------------------------------------------------------------------------


void Draw_Line(u08 sx,u08 sy,u08 ex, u08 ey, u16 color){
	
	if(sx==ex && sy == ey ) return;
	
	u08 x;

	u08 first_x = (sx<ex?sx:ex)&0x7F;
	u08 first_y = (sx<ex?sy:ey)&0x7F;

	u08 end_x		= (sx>ex?sx:ex)&0x7F;
	u08 end_y		= (sx>ex?sy:ey)&0x7F;
	
	float gradient = (end_y-first_y)/(end_x-first_x); 
	
	double current_y = 0;
	
	if(sx==ex)
	{
		 first_x = sy;
		 end_x =   ey; 
	
		 for(x=first_x;x<=end_x;x++)
		{			
			PutPixel(sx,x,color);

		}
	 }

	else
	{
		for(x=first_x;x<=end_x;x++)
		{
			current_y = (gradient*(x-first_x)+first_y);
			PutPixel(x,(u08)current_y,color);

		}
	}	

}

void Draw_Rectanle(u08 sx,u08 sy,u08 ex, u08 ey,u16 outColor,u16 inColor){
	
	if(sx==ex && sy == ey ) return;
	
	u08 x,y;

	u08 first_x = (sx<ex?sx:ex)&0x7F;
	u08 first_y = (sx<ex?sy:ey)&0x7F;

	u08 end_x		= (sx>ex?sx:ex)&0x7F;
	u08 end_y		= (sx>ex?sy:ey)&0x7F;

	for(y=first_y;y<=end_y;y++) //���� �簢�� �׸���
	{
		SetAddr(first_x,y);

		for(x=first_x;x<=end_x;x++)
		{
			write_data(inColor>>8);
			write_data(inColor&0xFF);			
		}	
	}	

	Draw_Line(first_x,first_y,end_x,first_y,outColor);//-
	Draw_Line(end_x,first_y,end_x,end_y,outColor); //   |
	Draw_Line(first_x,first_y,first_x,end_y,outColor); // | 
	Draw_Line(first_x,end_y,end_x,end_y,outColor); // _

}

void Draw_Circle(u08 x,u08 y,u08 rad, u16 inColor,u16 outColor){
	
	if((x+rad > 127 ) || (y+rad > 127 ) || (x-rad < 0 ) ||(y-rad < 0 ))
		return ;
	
	u08 i=1,j;
	
	char sx = x&0x7F;
	char sy = y&0x7F;	
	
	u16 radius = rad * rad;	

	for(i=0;i<=rad;i++)
	{
		j = (u08)(sqrt(radius-i*i)+0.5);		
	
		Draw_Line(sx+i,sy-j,sx+i,sy+j,inColor);
		Draw_Line(sx-i,sy-j,sx-i,sy+j,inColor);
	
	/*	PutPixel(x+i,y+j,outColor);//1
		PutPixel(x+i,y-j,outColor);//4
		PutPixel(x-i,y+j,outColor);//2
		PutPixel(x-i,y-j,outColor);//3
	*/		
	} 
		
}


void Print_text(u08 x,u08 y, char *text,u16 color){

	u08 b=0,c=0;
	u08 i,j,k=0,l=0;
	i=0,j=0;
	
	u08 ystep=0x01;
	i=y;
	j=x;

	while(1){

		if(text[k]=='\0') //���ڿ� ���ΰ� ?
			break;			
		
		l=text[k]-32;	//��Ʈ���� �ش� ���ڰ� �ִ� ��ġ�� �Ǻ�  	
		k++;			//���ڿ� ���� 
		

	while(1){
	
		if((pgm_read_byte(&FONT8X15[l][b][c]) & ystep)) //����� ������ ��Ʈ�� 1 �ΰ� ?
			PutPixel(j,i++,0xffe0); //red				// ������ ����� �ȼ��� ���� ��´�.
		else
			i++;

		ystep<<=1;

	
		if(ystep==0x00) { //��Ʈ������ �����÷ο� �Ȱ�� ,�� ��� �񱳰� �����ٸ�,
			ystep=0x01;	 //�ʱ�ȭ 		
			
			if(c==1){
				b++;j++;c=0;i=y; 		
			}
			else 
				c++;
						
			if(b==8){  
				j+=5;i=y;c=0;b=0;	//�ش� ���ڿ��� ����� ������� ���� ���ڷ� 		
				break;
			}

			
		}//end if
	
}//while

}//while

	ms_delay(1);
}
