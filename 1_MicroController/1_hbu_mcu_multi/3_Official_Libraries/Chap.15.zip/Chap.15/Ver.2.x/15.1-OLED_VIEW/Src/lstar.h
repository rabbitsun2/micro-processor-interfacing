#include<avr/pgmspace.h>

extern const prog_uint16_t lstar0[];
extern const prog_uint16_t lstar1[];
