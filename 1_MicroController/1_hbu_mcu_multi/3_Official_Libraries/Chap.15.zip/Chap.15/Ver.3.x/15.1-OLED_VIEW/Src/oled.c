#include <avr/io.h>
#include <util/delay.h>
#include <avr/pgmspace.h>

#include "oled.h"


const prog_char GamaChar[] = {
	0x01,0x02,0x03,0x04,//R
	0x05,0x06,0x07,0x08,
	0x09,0x0A,0x0B,0x0C,
	0x0D,0x0E,0x0F,0x11,
	0x13,0x17,0x1B,0x1F,
	0x23,0x27,0x2F,0x35,
	0x3F,0x49,0x53,0x5D,
	0x63,0x6D,0x75,0x7F,
	
	0x02,0x03,0x04,0x05,//G
	0x07,0x09,0x0B,0x0D,
	0x0F,0x11,0x13,0x1B,
	0x21,0x25,0x29,0x2D,
	0x31,0x35,0x39,0x3D,
	0x41,0x45,0x49,0x4F,
	0x55,0x5B,0x61,0x67,
	0x6D,0x73,0x79,0x7F,

	0x01,0x02,0x03,0x04,//B
	0x05,0x06,0x07,0x08,
	0x09,0x0A,0x0B,0x0C,
	0x0D,0x0E,0x0F,0x11,
	0x13,0x17,0x1B,0x1F,
	0x23,0x27,0x2F,0x35,
	0x3F,0x49,0x53,0x5D,
	0x63,0x6D,0x75,0x7F
};

//==================================================
//==================================================
void SetAddr(unsigned char x, unsigned char y)
{
  
	write_cmd(SET_COLUMN_ADDRESS); //colum �ּ� 
	write_data(x); 
	write_data(0x7f);
	
	
	write_cmd(SET_ROW_ADDRESS);
	write_data(y);
	write_data(0x7f);
	
	write_cmd(WRITE_GRAM);
}


//==================================================
// Plot one point
// at x,y with pixel color
//==================================================
void PutPixel(unsigned char x, unsigned char y, unsigned int color)
{
	SetAddr(x,y);
	write_data(color >> 8);
	write_data(color);
}

//======================================================================//
void initOLED(void)
{		
	
	OLED_CTRL_DDR	=	0xFF;
	OLED_DATA_DDR	=	0xFF;

	OLED_CTRL_PORT	=	0xFF;
	OLED_DATABUS = 0;
	
	Reset_SSD1355();
	
	write_cmd(SOFT_RESET); 
	
	write_cmd(COMMAD_LOCK); 
	write_data(0xB3);

	write_cmd(SLEEP_MODE_OFF);
	write_cmd(DISPLAY_NORMAL);
	write_cmd(DISPLAY_INVERSE_OFF);
	write_cmd(DISPLAY_ALL_ONOFF);

	write_cmd(SET_COLUMN_ADDRESS);
	write_data(0x00);
	write_data(0x7F);
	write_cmd(SET_ROW_ADDRESS);
	write_data(0x00);
	write_data(0x7F);

	write_cmd(DISABLE_TEARING_EFFECT);
	write_cmd(MEMORY_ACCSEE_CNTL);
	write_data(0x88);
	write_data(0x01);

	write_cmd(INTERFACE_PIXEL_FORMAT);
	write_data(_65K_COLOURS);

	write_cmd(WRITE_LUMINANCE);
	write_data(0xF0);

	write_cmd(FUNC_SEL);
	write_data(0x01);

	write_cmd(CONTRAST_R); 
	write_data(0xC8); 
	write_cmd(CONTRAST_G); 
	write_data(0x55); 
	write_cmd(CONTRAST_B); 
	write_data(0x99); 

	write_cmd(FIRST_PRECHARGE); 
	write_data(0x1F); 

	write_cmd(SET_DISPLAY_OFFSET); 
	write_data(0x00); 

	write_cmd(SET_MUX_RATIO); 
	write_data(0x7F);  //127

	write_cmd(SET_PHASE_LENGTH); 
	write_data(0x55); 

	write_cmd(SECOND_PRECHARGE_PERIOD); 
	write_data(0x07); 

	write_cmd(SET_2TH_PRECHARGE_SPEED); 
	write_data(0x02); 

	write_cmd(GAMMA_LUT); 		
	
	unsigned char j;
	for(j=0;j<96;j++)
		write_data(pgm_read_byte(&GamaChar[j]));

	write_cmd(CLOCK_FREQUENCY);
	write_data(0x30);
	
	write_cmd(SET_VCOMH);
	write_data(0x00);

	write_cmd(SET_GPIO);
	write_data(0x00);
}

//======================================================================//
//======================================================================//
void Reset_SSD1355(void)
{
	_delay_ms(1);
	cbi(OLED_CTRL_PORT,RESETPIN_OLED);		// IOCLR=bRES;
	_delay_us(2);
	sbi(OLED_CTRL_PORT,RESETPIN_OLED);		// IOSET=bRES;
	_delay_ms(1);
}


void write_cmd(unsigned char cmd)
{
	cbi(OLED_CTRL_PORT,D_C);				// IOCLR=bD_C;	
	cbi(OLED_CTRL_PORT,WN_OLED);			// IOCLR=bR_W;
	cbi(OLED_CTRL_PORT,CS_OLED);			// IOCLR=bCS;

	OLED_DATABUS = cmd;		// IOSET=cmd;
	asm("nop");

	sbi(OLED_CTRL_PORT,WN_OLED);			// IOSET=bR_W;
	sbi(OLED_CTRL_PORT,CS_OLED);			// IOSET=bCS;
}

//======================================================================//
//======================================================================//
void write_data(unsigned char data)
{
	sbi(OLED_CTRL_PORT,D_C);				// IOSET=bD_C;
	cbi(OLED_CTRL_PORT,CS_OLED);			// IOCLR=bCS;
	cbi(OLED_CTRL_PORT,WN_OLED);			// IOCLR=bR_W;

	OLED_DATABUS = data;	// IOSET=data;
	asm("nop");

	sbi(OLED_CTRL_PORT,CS_OLED);			// IOSET=bCS;
	sbi(OLED_CTRL_PORT,WN_OLED);			// IOSET=bR_W;

}


//-----------------------------------------------------------------------------
// Function:    OLED_DrawImage
// Parameters:  left/top are the x/y coordinates of the top/left corner 
//              (for 4bpp x has to be an even number)
//              width/height of image (has to match image properties)
//              (for 4bpp width has to be an even number)
//              mask allows to shift the gray scale levels (e.g. to darken a picture)
// Returns:     nothing
// Description: sets a canvas the size of width/heigth and fills it with the
//              data of the image 
//-----------------------------------------------------------------------------


void Draw_Line(unsigned char sx,unsigned char sy,unsigned char ex, unsigned char ey, unsigned int color){
	
	if(sx==ex && sy == ey ) return;
	
	unsigned char x;

	unsigned char first_x = (sx<ex?sx:ex)&0x7F;
	unsigned char first_y = (sx<ex?sy:ey)&0x7F;

	unsigned char end_x		= (sx>ex?sx:ex)&0x7F;
	unsigned char end_y		= (sx>ex?sy:ey)&0x7F;
	
	float gradient = (end_y-first_y)/(end_x-first_x); 
	
	double current_y = 0;
	
	if(sx==ex)
	{
		 first_x = sy;
		 end_x =   ey; 
	
		 for(x=first_x;x<=end_x;x++)
		{			
			PutPixel(sx,x,color);

		}
	 }

	else
	{
		for(x=first_x;x<=end_x;x++)
		{
			current_y = (gradient*(x-first_x)+first_y);
			PutPixel(x,(unsigned char)current_y,color);

		}
	}	

}

void Draw_Rectanle(unsigned char sx,unsigned char sy,unsigned char ex, unsigned char ey,unsigned int outColor,unsigned int inColor){
	
	if(sx==ex && sy == ey ) return;
	
	unsigned char x,y;

	unsigned char first_x = (sx<ex?sx:ex)&0x7F;
	unsigned char first_y = (sx<ex?sy:ey)&0x7F;

	unsigned char end_x		= (sx>ex?sx:ex)&0x7F;
	unsigned char end_y		= (sx>ex?sy:ey)&0x7F;

	for(y=first_y;y<=end_y;y++) //���� �簢�� �׸���
	{
		SetAddr(first_x,y);

		for(x=first_x;x<=end_x;x++)
		{
			write_data(inColor>>8);
			write_data(inColor&0xFF);			
		}	
	}	

	Draw_Line(first_x,first_y,end_x,first_y,outColor);//-
	Draw_Line(end_x,first_y,end_x,end_y,outColor); //   |
	Draw_Line(first_x,first_y,first_x,end_y,outColor); // | 
	Draw_Line(first_x,end_y,end_x,end_y,outColor); // _

}

void Draw_Circle(unsigned char x,unsigned char y,unsigned char rad, unsigned int inColor,unsigned int outColor){
	
	if((x+rad > 127 ) || (y+rad > 127 ) || (x-rad < 0 ) ||(y-rad < 0 ))
		return ;
	
	unsigned char i=1,j;
	
	char sx = x&0x7F;
	char sy = y&0x7F;	
	
	unsigned int radius = rad * rad;	

	for(i=0;i<=rad;i++)
	{
		j = (unsigned char)(sqrt(radius-i*i)+0.5);		
	
		Draw_Line(sx+i,sy-j,sx+i,sy+j,inColor);
		Draw_Line(sx-i,sy-j,sx-i,sy+j,inColor);
	} 
		
}
