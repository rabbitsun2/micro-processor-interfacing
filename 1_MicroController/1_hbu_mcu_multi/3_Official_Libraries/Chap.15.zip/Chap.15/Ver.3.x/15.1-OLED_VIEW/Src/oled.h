#ifndef OLED_H
#define OLED_H

#include <compat/deprecated.h>
#include <math.h>

//--------------------------------------------------------------------------//
// General definitions
//--------------------------------------------------------------------------//
#define	uint  unsigned int
#define	uchar unsigned char

#define ON					1
#define	OFF					0
#define INPUT 				1
#define OUTPUT				0
#define	ENABLE				1
#define	DISABLE				0
#define	SET					1
#define	CLEAR				0
//#define TRUE				1
#define	FALSE				0

//--------------------------------------------------------------------------//
// OLED Interface
//--------------------------------------------------------------------------//
#define	CS_OLED			0		// OLED CS
#define	RESETPIN_OLED	1
#define	D_C				2
#define WN_OLED			3		// OLED WN : R/W#(WR#)
#define	RN_OLED			4		// OLED RN : E(RD#)


#define OLED_CTRL_PORT	PORTG
#define	OLED_DATABUS	PORTA

#define OLED_CTRL_DDR	DDRG
#define	OLED_DATA_DDR	DDRA


//--------------------------------------------------------------------------//
// SSD1355 Registers

//--------------------------------------------------------------------------//
#define	SET_COLUMN_ADDRESS			0x2A
#define	SET_ROW_ADDRESS				0x2B
#define	WRITE_GRAM					0x2C
#define DISABLE_TEARING_EFFECT		0x34
#define MEMORY_ACCSEE_CNTL			0x36
#define	INTERFACE_PIXEL_FORMAT		0x3A
#define EN_T_EFFECT					0x35
#define	SET_MUX_RATIO				0xCA
#define	SET_DISPLAY_OFFSET			0xC8
#define FUNC_SEL					0xB3
#define	CLOCK_FREQUENCY				0xD2

#define	CONTRAST_R					0xBA
#define	CONTRAST_G					0xBB
#define	CONTRAST_B					0xBC
#define WRITE_LUMINANCE				0x51

#define	DISPLAY_ALL_ONOFF			0x29
#define	DISPLAY_INVERSE_OFF			0x20
#define	DISPLAY_NORMAL				0x13

#define	GAMMA_LUT					0xBE

#define	SET_VSL_DISCHARGE_PATH		0xCC
#define	SET_PHASE_LENGTH			0xCD
#define	FIRST_PRECHARGE				0xBD
#define	SECOND_PRECHARGE_PERIOD		0xCE

#define	SET_2TH_PRECHARGE_SPEED		0xCE
#define	SET_VCOMH					0xD3

#define	SLEEP_MODE_ON				0x10
#define	SLEEP_MODE_OFF				0x11

#define COMMAD_LOCK					0xFD
#define SOFT_RESET					0x01

#define SET_GPIO					0xD7

#define	_65K_COLOURS				0x05
#define	_262K_COLOURS				0x06


#define RGB565(r,g,b) ( (((r)>>3)<<11) | (((g)>>2)<<5) | ((b)>>3) )


//--------------------------------------------------------------------------//
// Screen Related definitions
//--------------------------------------------------------------------------//
#define X_RES				128
#define Y_RES				128

#define MAXCOLOUR			0xFFFF
#define	MAX_TEXTROWS		25

#define BLACK				0x0000
#define WHITE				0xFFFF
#define	RED					0xF800
#define	GREEN				0x07E0
#define	BLUE				0x001F
#define	YELLOW				RED | GREEN


/****************************************************************************/
/*          				FUNCTION PROTOTYPES                				*/
/****************************************************************************/

void initOLED(void);
void SetAddr(unsigned char x, unsigned char y);
void PutPixel(unsigned char x, unsigned char y, unsigned int color);

void Reset_SSD1355(void);
void write_cmd(unsigned char);
void write_data(unsigned char);

void delay_1us(unsigned char u);
void DelayMs(unsigned int);


//3.13 New Fucn
void Draw_Line(unsigned char sx,unsigned char sy,unsigned char ex, unsigned char ey, unsigned int color);
void Draw_Rectanle(unsigned char sx,unsigned char sy,unsigned char ex, unsigned char ey,unsigned int outColor,unsigned int inColor);
void Draw_Circle(unsigned char x,unsigned char y,unsigned char rad, unsigned int inColor,unsigned int outColor);
#endif
